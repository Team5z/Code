package com.agile.demo.biz.task;

import com.agile.demo.biz.account.AccountEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "NTASK")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskEntity {
    @Id
    private Long seq;

    @Column(nullable = false, updatable = true, length = 100)
    private String Title;

    @Column(nullable = true, updatable = true)
    private int Story_Progress;

    @Column(nullable = true, updatable = true, length = 255)
    private String Description;

    @Column(nullable = true, updatable = true)
    private Long Assign;

    @Column
    private LocalDateTime createDate;

    @Column
    private LocalDateTime updataData;

    @Column(nullable = false, updatable = true)
    private Long Presenter;

    @Column(nullable = false, updatable = true)
    private Long manager;

    // @Enumerated(EnumType.STRING)
    // private Role role;


    public Long getSeq() {
        return seq;
    }

    public void setSeq(Long seq) {
        this.seq = seq;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public int getStory_Progress() {
        return Story_Progress;
    }

    public void setStory_Progress(int story_Progress) {
        Story_Progress = story_Progress;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public Long getAssign() {
        return Assign;
    }

    public void setAssign(Long assign) {
        Assign = assign;
    }

    public LocalDateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    public LocalDateTime getUpdataData() {
        return updataData;
    }

    public void setUpdataData(LocalDateTime updataData) {
        this.updataData = updataData;
    }

    public Long getPresenter() {
        return Presenter;
    }

    public void setPresenter(Long presenter) {
        Presenter = presenter;
    }

    public Long getManager() {
        return manager;
    }

    public void setManager(Long manager) {
        this.manager = manager;
    }

    public AccountEntity getAccount() {
        return account;
    }

    public void setAccount(AccountEntity account) {
        this.account = account;
    }

    @OneToOne
    @JoinColumn(name = "seq", insertable = false, unique = true, updatable = false)
    private AccountEntity account;
}
