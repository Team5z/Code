package com.agile.demo.biz.account;

import lombok.*;

import javax.persistence.*;
import java.util.Date;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Table;

@Entity
@Table(name = "NAccount")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class AccountEntity {

    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(nullable = false, length = 25, unique = true)
    private long seq;

    @Column(nullable = false, updatable = false, length = 50)
    private String name;

    @Column(nullable = false, length = 50)
    private String password;

    @Column(nullable = false, updatable = false, length = 50, unique = true)
    private String email;

    @Column(nullable = true, updatable = true, length = 11)
    private String cellphone;

    private Date regDate;


    // @Enumerated(EnumType.STRING)
    // private RoleType roleType;

    // @OneToMany(cascade = CascadeType.MERGE)

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public long getSeq() {
        return seq;
    }

    public void setSeq(long seq) {
        this.seq = seq;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }
}


