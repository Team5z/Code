package com.agile.demo.biz.project;

import com.agile.demo.biz.backlog.BacklogEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "NProject")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class ProjectEntity {

    @Id
    private long seq;

    @Column(nullable = false, updatable = true, length = 100)
    private String Project_Title;

    @Column(nullable = true, updatable = true)
    private String Project_Assign;

    // @Column(nullable = false, updatable = true)
    // private

    public long getSeq() {
        return seq;
    }

    public void setSeq(long seq) {
        this.seq = seq;
    }

    public String getProject_Title() {
        return Project_Title;
    }

    public void setProject_Title(String project_Title) {
        Project_Title = project_Title;
    }

    public String getProject_Assign() {
        return Project_Assign;
    }

    public void setProject_Assign(String project_Assign) {
        Project_Assign = project_Assign;
    }

    public List<BacklogEntity> getBacklogs() {
        return backlogs;
    }

    public void setBacklogs(List<BacklogEntity> backlogs) {
        this.backlogs = backlogs;
    }

    @OneToMany(cascade = CascadeType.REMOVE)
   private List<BacklogEntity> backlogs;       // 체크 필요

    
}
